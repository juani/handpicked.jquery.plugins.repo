function boot(){if(!
/*@cc_on!@*/
0){return}var all=document.getElementsByTagName("*"),i=all.length;while(i--){if(all[i].scrollWidth>all[i].offsetWidth){all[i].style.paddingBottom="32px";all[i].style.overflowY="hidden"}}};