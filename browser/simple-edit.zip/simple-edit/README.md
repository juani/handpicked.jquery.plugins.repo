Simple Edit v0.1

Usage: yourElement.simpleEdit();

Options: defaultText