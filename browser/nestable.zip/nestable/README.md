Nestable
========

### Drag & drop hierarchical list with mouse and touch compatibility (jQuery plugin)

[**Try Nestable Demo**](http://dbushell.github.com/Nestable/)

* * *

Author: David Bushell [http://dbushell.com](http://dbushell.com/) [@dbushell](http://twitter.com/dbushell/)

Copyright © 2012 David Bushell | BSD & MIT license
